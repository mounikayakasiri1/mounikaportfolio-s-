const form = document.getElementById("studentForm");
const studentId = document.getElementById("studentId");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const courseInput = document.getElementById("course");
const submitButton = document.getElementById("submitButton");
const cancelButton = document.getElementById("cancelButton");
const table = document.getElementById("studentTable");
const message = document.getElementById("message");

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const student = {
        name: nameInput.value,
        email: emailInput.value,
        course: courseInput.value
    };

    try {
        let response;

        if (studentId.value) {
            response = await fetch(`/students/${studentId.value}`, {
                method: "PUT",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(student)
            });
        } else {
            response = await fetch("/students", {
                method: "POST",
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify(student)
            });
        }

        if (!response.ok) {
            throw new Error("Request failed");
        }

        showMessage(await response.text());
        resetForm();
        await loadStudents();

    } catch (error) {
        showMessage("Something went wrong.", true);
        console.error(error);
    }
});

cancelButton.addEventListener("click", resetForm);

async function loadStudents() {
    try {
        const response = await fetch("/students");
        const students = await response.json();

        table.innerHTML = "";

        students.forEach(student => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${student.id}</td>
                <td>${escapeHtml(student.name)}</td>
                <td>${escapeHtml(student.email)}</td>
                <td>${escapeHtml(student.course)}</td>
                <td>
                    <button class="action-button" onclick="editStudent(${student.id}, '${escapeJs(student.name)}', '${escapeJs(student.email)}', '${escapeJs(student.course)}')">Edit</button>
                    <button class="action-button danger" onclick="deleteStudent(${student.id})">Delete</button>
                </td>
            `;

            table.appendChild(row);
        });
    } catch (error) {
        showMessage("Could not load students.", true);
        console.error(error);
    }
}

function editStudent(id, name, email, course) {
    studentId.value = id;
    nameInput.value = name;
    emailInput.value = email;
    courseInput.value = course;

    submitButton.textContent = "Update Student";
    cancelButton.classList.remove("hidden");
}

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) {
        return;
    }

    try {
        const response = await fetch(`/students/${id}`, {
            method: "DELETE"
        });

        if (!response.ok) {
            throw new Error("Delete failed");
        }

        showMessage(await response.text());
        await loadStudents();

    } catch (error) {
        showMessage("Could not delete student.", true);
        console.error(error);
    }
}

function resetForm() {
    form.reset();
    studentId.value = "";
    submitButton.textContent = "Add Student";
    cancelButton.classList.add("hidden");
}

function showMessage(text, isError = false) {
    message.textContent = text;
    message.style.fontWeight = "bold";
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function escapeJs(value) {
    return String(value)
        .replaceAll("\\", "\\\\")
        .replaceAll("'", "\\'");
}

loadStudents();
