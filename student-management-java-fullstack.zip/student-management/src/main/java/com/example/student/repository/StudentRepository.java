package com.example.student.repository;

import com.example.student.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentRepository {

    private final JdbcTemplate jdbcTemplate;

    public StudentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int save(Student student) {
        String sql = "INSERT INTO students(name, email, course) VALUES (?, ?, ?)";
        return jdbcTemplate.update(
                sql,
                student.getName(),
                student.getEmail(),
                student.getCourse()
        );
    }

    public List<Student> findAll() {
        String sql = "SELECT id, name, email, course FROM students";

        return jdbcTemplate.query(sql, (rs, rowNum) ->
                new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("course")
                )
        );
    }

    public int update(int id, Student student) {
        String sql = "UPDATE students SET name = ?, email = ?, course = ? WHERE id = ?";

        return jdbcTemplate.update(
                sql,
                student.getName(),
                student.getEmail(),
                student.getCourse(),
                id
        );
    }

    public int delete(int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        return jdbcTemplate.update(sql, id);
    }
}
