# Student Management System

A simple Java full-stack application using:

- Java 17
- Spring Boot
- Spring JDBC / JdbcTemplate
- MySQL
- HTML
- CSS
- JavaScript
- Maven

## Setup

1. Install JDK 17+ and Maven.
2. Install MySQL.
3. Run `database.sql` in MySQL.
4. Open `src/main/resources/application.properties`.
5. Replace `YOUR_MYSQL_PASSWORD` with your MySQL password.
6. Run:

```bash
mvn spring-boot:run
```

7. Open:

```text
http://localhost:8080
```

## APIs

- POST `/students` - add student
- GET `/students` - list students
- PUT `/students/{id}` - update student
- DELETE `/students/{id}` - delete student

## Project flow

Frontend -> REST Controller -> Service -> Repository -> JdbcTemplate -> MySQL
